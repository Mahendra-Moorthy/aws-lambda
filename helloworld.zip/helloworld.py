def hello(event, context)
    print("hello world")
